package assignment7;

public interface MessageListener {
	public void receive(String fromUser, String msg);
}
